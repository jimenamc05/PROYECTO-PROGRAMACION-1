package service;

import java.util.Scanner;
import model.Alumno;
import model.Materia;
import model.Matricula;


public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        Alumno alumno = new Alumno();
        Materia materia = new Materia();


        String menu = "Digite: \n1 - Registrar Alumno\n2 - Registrar materia\n3 - Registrar su matrícula\n4 - Salir";
        int opcion = 0;
        int idAlumno;
        String nombre;
        int edad;
        String codigo;
        int creditos;
        String profesor;
        String fecha;
        String sede;
        




        do{
            System.out.println(menu);
            opcion = scan.nextInt();


            switch (opcion){

                case 1:
                    System.out.println("Ingrese ID de alumno.");
                    idAlumno = scan.nextInt();

                    System.out.println("Ingrese el nombre del alumno.");
                    nombre = scan.next();

                    System.out.println("Ingrese la edad del alumno.");
                    edad = scan.nextInt();



                    break;
                case 2:
                    System.out.println("Ingrese el código de su materia a registrar.");
                    codigo = scan.next();

                    System.out.println("Ingrese el número de créditos que dispone:");
                    creditos = scan.nextInt();
                    
                    System.out.println("Ingrese el nombre del profesor/a.");
                    profesor = scan.next();

                    break;
                case 3:
                    if(!alumno.getNombre().equals("") && !materia.getCodigo().equals("")){
                        System.out.println("Ingrese la fecha de ingreso.");
                        fecha = scan.next();

                        System.out.println("Ingrese la sede en la que desea matricular.");
                        sede = scan.next();
                    }else{
                        System.out.println("Por favor, primero ingrese los datos del alumno y de la materia.");
                    }

                    break;
                case 4:


                    break;
            }


        }while(opcion != 4);
    
    
        scan.close();
    }
}
