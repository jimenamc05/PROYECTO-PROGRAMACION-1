package model;

public class Matricula {
    private String fecha; 
    private String sede; 
    private Alumno alumno; 
    private Materia materia; 

 public Matricula(){

 }
    public String getFecha(){
        return this.fecha;
    
    }

    public void setFecha(String pFecha){
        this.fecha = pFecha;
    }

    public String getSede(){
        return this.sede;
    
    }

    public void setSede( String pSede){
        this.sede  = pSede;


    } 
    public Alumno getAlumno(){
        return this.alumno;
    
    }

    public void setAlumno( Alumno pAlumno){
        this.alumno = pAlumno;

    }
     public Materia getMateria(){
        return this.materia;
    
    }

    public void setMateria (Materia pMateria ){
        this.materia = pMateria;
    }

    public String mostrarInfo() {
        return ("Fecha: " + fecha + "\nSede: s" + sede);
    }
}
