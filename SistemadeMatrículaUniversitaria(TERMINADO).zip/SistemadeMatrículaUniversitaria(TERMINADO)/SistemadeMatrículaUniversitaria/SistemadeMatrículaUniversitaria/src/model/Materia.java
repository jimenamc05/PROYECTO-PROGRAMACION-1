package model;

public class Materia {
    private String codigo;
    private int creditos;
    private String profesor;

    public Materia(){

    }

    public String getCodigo(){
        return this.codigo;
    
    }

    public void setCodigo(String pCodigo){
        this.codigo = pCodigo;
    }

    public int getCredito(){
        return this.creditos;
    
    }

    public void setCredito(int pCreditos){
        this.creditos = pCreditos;
    }

    public String getProfesor(){
        return this.profesor;
    
    }

    public void setProfesor(String pProfesor){
        this.profesor = pProfesor;
        
    }
    public String mostrarInfo() {
        return ("------------------------------------------------\n\nCódigo  de su materia: " + codigo+ "\nCréditos que dispone la materia: " + creditos + "\nProfesor: " + profesor + "\n\n------------------------------------------------");
    }
}