package service;

import java.util.Scanner;
import model.Alumno;
import model.Materia;
import model.Matricula;

public class App {
    public static void main(String[] args) throws Exception {

        Scanner scan = new Scanner(System.in);
        Alumno alumno = null;
        Materia materia = null;
        Matricula matricula = null;

        int opcionSubmenu = 0;
        int opcion = 0;
        String menu = "------------------------------------------------\n\nMENÚ DEL SISTEMA: \n\nDigite: \n1 - Registrar Alumno\n2 - Registrar materia\n3 - Registrar su matrícula\n4 - Buscar alumno por nombre\n5 - Buscar materia por créditos\n6 - Buscar matrícula por sede\n7 - Salir\n\n------------------------------------------------\nIntegrantes del grupo:\nAlissa Monge Mata\nJimena Marín Castro\n------------------------------------------------";
        String submenu = "1 - Agregar \n2 - Modificar";
        int idAlumno;
        String nombre;
        int edad;
        String codigo;
        int creditos;
        String profesor;
        String fecha;
        String sede;
        int n; //para la extensión de los vectores, cantidad de lotes en total
        int posicion;
    
        //definición extensión de los vectores 
        System.out.println("Digite la cantidad de estudiantes, materias, matriculas a registrar");
        n = scan.nextInt();
            Alumno vectorAlumno[]=new Alumno[n];
            Materia vectorMateria[]= new Materia[n];
            Matricula vectorMatricula[] = new Matricula[n];

         

        do {
           

            System.out.println(menu);
            opcion = scan.nextInt();

            switch (opcion) {

                case 1:
                  //este caso es para la información del alumno

                    System.out.println("Introduzca el lote en el que se va a trabajar");
                    posicion=scan.nextInt();

                    
                    System.out.println(submenu);
                    opcionSubmenu = scan.nextInt();

                    switch (opcionSubmenu) {
                        case 1:
                            alumno = new Alumno();

                            System.out.println("Ingrese ID de alumno.");
                            idAlumno = scan.nextInt();
                            alumno.setIdAlumno(idAlumno);

                            System.out.println("Ingrese el nombre del alumno.");
                            nombre = scan.next();
                            alumno.setNombre(nombre);

                            System.out.println("Ingrese la edad del alumno.");
                            edad = scan.nextInt();
                            alumno.setEdad(edad);

                            vectorAlumno[posicion] = alumno;

                            break;
                        case 2:
                            
            
                            if (vectorAlumno[posicion] != null) {
                                System.out.println("Ingrese nuevo ID de alumno.");
                                idAlumno = scan.nextInt();
                                alumno.setIdAlumno(idAlumno);

                                System.out.println("Ingrese el nuevo nombre del alumno.");
                                nombre = scan.next();
                                alumno.setNombre(nombre);

                                System.out.println("Ingrese la nueva edad del alumno.");
                                edad = scan.nextInt();
                                alumno.setEdad(edad);
                                vectorAlumno[posicion]= alumno;
                            } else {
                                System.out.println("No hay datos por modificar. Agréguelos.");
                            }

                            break;

                    }

                    break;
                case 2:
                 //este caso es para la información de la materia

                    System.out.println("Introduzca el lote en el que se va a trabajar");
                         posicion=scan.nextInt();

                    System.out.println(submenu);
                    opcionSubmenu = scan.nextInt();

                    switch (opcionSubmenu) {
                        case 1:
                            materia = new Materia();

                            System.out.println("Ingrese el código de su materia a registrar.");
                            codigo = scan.next();
                            materia.setCodigo(codigo);

                            System.out.println("Ingrese el número de créditos que dispone:");
                            creditos = scan.nextInt();
                            materia.setCredito(creditos);

                            System.out.println("Ingrese el nombre del profesor/a.");
                            profesor = scan.next();
                            materia.setProfesor(profesor);
                            
                            vectorMateria[posicion]= materia;
                            break;

                        case 2:
                            
                            if (vectorMateria[posicion] != null) {
                                System.out.println("Ingrese el nuevo código de su materia a registrar.");
                                codigo = scan.next();
                                materia.setCodigo(codigo);

                                System.out.println("Ingrese el nuevo número de créditos que dispone:");
                                creditos = scan.nextInt();
                                materia.setCredito(creditos);

                                System.out.println("Ingrese el nuevo nombre del profesor/a.");
                                profesor = scan.next();
                                materia.setProfesor(profesor);
                                vectorMateria[posicion]= materia;
                            } else {
                                System.out.println("No hay datos por modificar. Agréguelos.");
                            }

                            break;

                    }

                    break;
                case 3:
                 //este caso es para la información de la matrícula


                    System.out.println("Introduzca el lote en el que se va a trabajar");
                    posicion=scan.nextInt();

                    if (vectorAlumno[posicion]!= null && vectorMateria[posicion] != null) {
                        
                        System.out.println(submenu);
                        opcionSubmenu = scan.nextInt();

                        switch (opcionSubmenu) {
                            case 1:
                                matricula = new Matricula();

                                System.out.println("Ingrese la fecha de ingreso.");
                                fecha = scan.next();
                                matricula.setFecha(fecha);

                                System.out.println("Ingrese la sede en la que desea matricular.");
                                sede = scan.next();
                                matricula.setSede(sede);
                                    vectorMatricula[posicion]=matricula; 
                                break;
                            case 2:
                                if (matricula != null) {
                                    System.out.println("Ingrese la nueva fecha de ingreso.");
                                    fecha = scan.next();
                                    matricula.setFecha(fecha);

                                    System.out.println("Ingrese la nueva sede en la que desea matricular.");
                                    sede = scan.next();
                                    matricula.setSede(sede);

                                    vectorMatricula[posicion]=matricula;
                                } else {
                                    System.out.println("No hay datos por modificar. Agréguelos.");
                                }
                                        
                                break;
                        }

                    } else {
                        System.out.println("Por favor, primero ingrese los datos del alumno y de la materia.");
                    }

                    break;
                case 4:
                 //este caso es para buscar info. de alumno por el nombre

                    String nombreBuscar;
                    System.out.println("Digite el nombre del alumno a buscar:");
                    nombreBuscar = scan.next();
                    for (int z = 0 ; z < vectorAlumno.length; z++){
                        if(vectorAlumno[z].getNombre().equals(nombreBuscar)){
                            System.out.println(vectorAlumno[z].mostrarInfo());
                        } 
                    }
                 

                    break;

                case 5:
                 //este caso es para buscar materias por créditos superiores a los ingresados por el usuario en la línea 221
                    int creditosBuscar;
                    System.out.println("Ingrese la cantidad de créditos a buscar (Se mostrarán las materias con créditos superiores a esta cifra)");
                    creditosBuscar = scan.nextInt();
                    
                    for (int z = 0 ; z < vectorMateria.length; z++){
                        if( vectorMateria[z].getCredito() > creditosBuscar){
                            System.out.println(vectorMateria[z].mostrarInfo());
                        }
                    }
                    
                    break;

                case 6:
                 //este caso es para buscar info. de matrículas por sede, excluyendo las que tengan la misma sede que ingrese el usuario en la línea 235
                    String sedeBuscar;
                    System.out.println("Digite el nombre de la sede a EXCLUIR en la búsqueda:");
                    sedeBuscar = scan.next();

                    for (int z = 0 ; z < vectorMatricula.length; z++){
                        if(!vectorMatricula[z].getSede().equals(sedeBuscar)){
                            System.out.println(vectorMatricula[z].mostrarInfo());
                        }
                    }

                    break;

                case 7:
                    System.out.println("Salió del sistema.");

                    break;
                default:
                    System.out.println("ERROR: Ingrese alguna de las opciones predeterminadas.");
                    break;
            }

        } while (opcion != 7);

        scan.close();
    }
}