package model;

public class Alumno {
    private int idAlumno;
    private String nombre;
    private int edad;

    public Alumno() {

    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String pNombre) {
        this.nombre = pNombre;
    }

    public int getIdAlumno() {
        return this.idAlumno;
    }

    public void setIdAlumno(int pIdAlumno) {
        this.idAlumno = pIdAlumno;
    }

    public int getEdad() {
        return this.edad;
    }

    public void setEdad(int pEdad) {
        this.edad = pEdad;
    }

    public String mostrarInfo() {
        return ("ID: " + idAlumno + "\nNombre: " + nombre + "\nEdad: " + edad);
    }

}