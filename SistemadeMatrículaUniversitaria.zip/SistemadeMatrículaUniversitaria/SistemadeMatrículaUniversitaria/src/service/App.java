package service;

import java.util.Scanner;
import model.Alumno;
import model.Materia;
import model.Matricula;

public class App {
    public static void main(String[] args) throws Exception {

        Scanner scan = new Scanner(System.in);
        Alumno alumno = null;
        Materia materia = null;
        Matricula matricula = null;

        int opcionSubmenu = 0;
        int opcion = 0;
        String menu = "MENU OPCIONES PREDETERMINADAS: \n\nDigite: \n1 - Registrar Alumno\n2 - Registrar materia\n3 - Registrar su matrícula\n4 - Mostrar info. alumno\n5 - Mostrar info. materia\n6 - Mostrar info. matrícula\n7 - Salir";
        String submenu = "1 - Agregar \n2 - Modificar";
        int idAlumno;
        String nombre;
        int edad;
        String codigo;
        int creditos;
        String profesor;
        String fecha;
        String sede;
        int n; 
        int posicion;
    
 //vector 
                System.out.println("Digite la cantidad de estudiantes, materias, matriculas a registrar");
                    n = scan.nextInt();
                     Alumno vectorAlumno[]=new Alumno[n];

                     Materia vectorMateria[]= new Materia[n];

                     Matricula vectorMatricula[] = new Matricula[n];

         

        do {
           

            System.out.println(menu);
            opcion = scan.nextInt();

            switch (opcion) {

                case 1:
                  

                     System.out.println("Introduzca el lote en el que se va a trabajar");
                    posicion=scan.nextInt();


                    System.out.println(submenu);
                    opcionSubmenu = scan.nextInt();

                    switch (opcionSubmenu) {
                        case 1:
                            alumno = new Alumno();

                            System.out.println("Ingrese ID de alumno.");
                            idAlumno = scan.nextInt();
                            alumno.setIdAlumno(idAlumno);

                            System.out.println("Ingrese el nombre del alumno.");
                            nombre = scan.next();
                            alumno.setNombre(nombre);

                            System.out.println("Ingrese la edad del alumno.");
                            edad = scan.nextInt();
                            alumno.setEdad(edad);

                            vectorAlumno[posicion] = alumno;

                            break;
                        case 2:

            
                            if (vectorAlumno[posicion] != null) {
                                System.out.println("Ingrese nuevo ID de alumno.");
                                idAlumno = scan.nextInt();
                                alumno.setIdAlumno(idAlumno);

                                System.out.println("Ingrese el nuevo nombre del alumno.");
                                nombre = scan.next();
                                alumno.setNombre(nombre);

                                System.out.println("Ingrese la nueva edad del alumno.");
                                edad = scan.nextInt();
                                alumno.setEdad(edad);
                                vectorAlumno[posicion]= alumno;
                            } else {
                                System.out.println("No hay datos por modificar. Agréguelos.");
                            }

                            break;

                    }

                    break;
                case 2:
                    System.out.println("Introduzca el lote en el que se va a trabajar");
                         posicion=scan.nextInt();

                    System.out.println(submenu);
                    opcionSubmenu = scan.nextInt();

                    switch (opcionSubmenu) {
                        case 1:
                            materia = new Materia();

                            System.out.println("Ingrese el código de su materia a registrar.");
                            codigo = scan.next();
                            materia.setCodigo(codigo);

                            System.out.println("Ingrese el número de créditos que dispone:");
                            creditos = scan.nextInt();
                            materia.setCredito(creditos);

                            System.out.println("Ingrese el nombre del profesor/a.");
                            profesor = scan.next();
                            materia.setProfesor(profesor);
                            
                            vectorMateria[posicion]= materia;
                            break;

                        case 2:
                            
                            if (vectorMateria[posicion] != null) {
                                System.out.println("Ingrese el nuevo código de su materia a registrar.");
                                codigo = scan.next();
                                materia.setCodigo(codigo);

                                System.out.println("Ingrese el nuevo número de créditos que dispone:");
                                creditos = scan.nextInt();
                                materia.setCredito(creditos);

                                System.out.println("Ingrese el nuevo nombre del profesor/a.");
                                profesor = scan.next();
                                materia.setProfesor(profesor);
                                vectorMateria[posicion]= materia;
                            } else {
                                System.out.println("No hay datos por modificar. Agréguelos.");
                            }

                            break;

                    }

                    break;
                case 3:
                 System.out.println("Introduzca el lote en el que se va a trabajar");
                         posicion=scan.nextInt();

                    if (vectorAlumno[posicion]!= null && vectorMateria[posicion] != null) {
                        
                        System.out.println(submenu);
                        opcionSubmenu = scan.nextInt();

                        switch (opcionSubmenu) {
                            case 1:
                                matricula = new Matricula();

                                System.out.println("Ingrese la fecha de ingreso.");
                                fecha = scan.next();
                                matricula.setFecha(fecha);

                                System.out.println("Ingrese la sede en la que desea matricular.");
                                sede = scan.next();
                                matricula.setSede(sede);
                                    vectorMatricula[posicion]=matricula; 
                                break;
                            case 2:
                                if (matricula != null) {
                                    System.out.println("Ingrese la nueva fecha de ingreso.");
                                    fecha = scan.next();
                                    matricula.setFecha(fecha);

                                    System.out.println("Ingrese la nueva sede en la que desea matricular.");
                                    sede = scan.next();
                                    matricula.setSede(sede);

                                    vectorMatricula[posicion]=matricula;
                                } else {
                                    System.out.println("No hay datos por modificar. Agréguelos.");
                                }
                                        
                                break;
                        }

                    } else {
                        System.out.println("Por favor, primero ingrese los datos del alumno y de la materia.");
                    }

                    break;
                case 4:
                    System.out.println("Ingrese el lote a buscar:");
                    posicion= scan.nextInt();
                 if (vectorAlumno[posicion] != null) {
                        System.out.println("Mostrar alumno");
                        System.out.println(vectorAlumno[posicion].mostrarInfo());

                    } else {
                        System.out.println("Información no registrada");

                    }

                    break;

                case 5:
                    System.out.println("Ingrese el valor que desea consultar:");
                    posicion= scan.nextInt();
                    if (vectorMateria[posicion]!= null) {
                        System.out.println("Mostrar materia registrda");
                        System.out.println(vectorMateria[posicion].mostrarInfo());

                    } else {
                        System.out.println("Información no registrada");
                    }

                    break;

                case 6:
                    if (matricula != null) {
                        System.out.println("Mostrar Matricula");
                        System.out.println(matricula.mostrarInfo());

                    } else {
                        System.out.println("Información no registrada");
                    }
                    break;

                case 7:
                    System.out.println("Salió del sistema.");

                    break;
                default:
                    System.out.println("ERROR: Ingrese alguna de las opciones predeterminadas.");
                    break;
            }

        } while (opcion != 7);

        scan.close();
    }
}
